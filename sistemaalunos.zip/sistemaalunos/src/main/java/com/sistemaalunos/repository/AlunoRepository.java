package com.sistemaalunos.repository;

import org.springframework.data.repository.CrudRepository;

import com.sistemaalunos.models.Aluno;

public interface AlunoRepository extends CrudRepository<Aluno, String>{

}
