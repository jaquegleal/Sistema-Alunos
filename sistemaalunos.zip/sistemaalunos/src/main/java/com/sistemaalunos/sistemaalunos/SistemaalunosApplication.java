package com.sistemaalunos.sistemaalunos;

import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaalunosApplication{

	public static void main(String[] args) {
		SpringApplication.run(SistemaalunosApplication.class, args);
	}

}
